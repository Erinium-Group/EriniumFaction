package fr.eriniumgroup.eriniumfaction.mixin;

import fr.eriniumgroup.eriniumfaction.EriFont;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.entity.Entity;

@Mixin(Entity.class)
public abstract class PoubelleMixin {
}