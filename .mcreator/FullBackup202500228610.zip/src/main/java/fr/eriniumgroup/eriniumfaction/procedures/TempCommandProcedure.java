package fr.eriniumgroup.eriniumfaction.procedures;

public class TempCommandProcedure {
	public static void execute() {
		boolean temp = false;
		boolean changed = false;

        new Thread(() -> {
            Boolean test;

            test = true;
        });
	}
}