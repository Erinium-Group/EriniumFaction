# \## License

# 

# This project is protected by the \*\*Erinium Faction Mod License v1.0\*\*.  

# All rights are reserved by the author.  

# 

# \- You are \*\*not allowed\*\* to copy, redistribute, modify, or use this code/content outside the official Erinium Faction project.  

# \- Running, reverse engineering, or attempting to bypass restrictions is strictly forbidden unless explicitly approved by the author.  

# \- The name \*\*Erinium Faction\*\* and all related assets, code, and content are the exclusive property of the author.  

# \- Any unauthorized commercial use (sale, monetization, private servers, etc.) is prohibited.  

# 

# ➡️ See the full license text in the \[LICENSE](LICENSE) file.



